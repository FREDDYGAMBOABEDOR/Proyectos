import java.sql.Connection;

public class conexion{
	Connection conn = null;
	String pass = "1234";
	String user = "postgres";

	public void conectar{
		try{
			conn = DriverManager.getConnection("jbdc:postgresql://localhost:5432/Bd_bitacoras",user,pass);
			JOptionPane.showMessageDialog(null, "Grabado");
		}
		catch(SQLException ex){
			JoptionPane.showMessageDialog(null, ex);
		}
	}
}